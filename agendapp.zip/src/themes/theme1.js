export const Theme1 = {
    primary: '#0f66ff',
    secoundary: '#FA7A01',
    danger: '#d50000'
}

export const NotFound = () => (
    <p>404 Page not found</p>
)
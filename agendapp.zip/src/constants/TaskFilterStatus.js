export const STATUS_FILTER = {
    ALL: 0,
    NEW: 1,
    IN_PROGRESS: 2,
    DUE_DATE: 3,
    CLOSED: 4
  };

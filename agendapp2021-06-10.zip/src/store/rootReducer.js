import { combineReducers } from "redux";
import taskReducer from "./tasks/taskReducer";
import userReducer from "./user/userReducer"
import responsibleReducer from "./responsibles/responsibleReducer";
const rootReducer = combineReducers({
    task: taskReducer,
    user: userReducer,
    responsibles: responsibleReducer
});

export default rootReducer;

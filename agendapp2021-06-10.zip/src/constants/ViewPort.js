export const SCREEN_VIEWPORT = {
    DESKTOP: 'desktop',
    MOBILE:'mobile'
}

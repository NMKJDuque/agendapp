export const USERS = {
    login: 'auth/signin',
    check: 'auth/check'
    
};

export const TASK = {
    getTask: 'tasks',
    createTask: 'tasks/create'
};

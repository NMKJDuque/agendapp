import { LoadingProgress } from "./styles";

export const Loading = () => (
    <LoadingProgress>
        <p>Loading...</p>
    </LoadingProgress>
)

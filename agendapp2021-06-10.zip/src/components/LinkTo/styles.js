import styled from "styled-components";

export const LinkWrapper = styled.span`
    a{
        color: #0f66ff;
        text-decoration: none;
    }
`;
